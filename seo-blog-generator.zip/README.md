# AI-Driven SEO Blog Generation — README (Assignment Deliverable)

## Flow (High-level)
```mermaid
flowchart TD
  A[Input: Competitor Blog URL]
  B[Fetch & Sanitize\n(HTTP fetch + Cheerio)\nFallback: Playwright]
  C[Content Extraction\n(H1-H6, paragraphs, meta, entities)]
  D[Semantic Brief\n(Outline, keywords, gaps, tone)]
  E[Draft Generation\n(RAG + LLM, section-by-section, HTML)]
  F[Safety & QA\n(similarity, plagiarism, SEO checks, facts)]
  G[Human Review]
  H[Output: Review-ready HTML Draft\n+ metadata, schema, links, images]

  A --> B
  B --> C
  C --> D
  D --> E
  E --> F
  F --> G
  G --> H
```

## Narrative (concise)
**Goal.** Convert a competitor blog URL into a production-ready Sendmarc blog draft: original copy, HTML-structured, brand tone, SEO-aware, and safe for publishing.

**Steps:**
1. **Input** — competitor URL.
2. **Fetch & Sanitize** — fast fetch + Cheerio; fallback to Playwright for JS-rendered sites. Remove UI noise.
3. **Content Extraction** — extract title, headings, paragraphs, meta; produce embedding.
4. **Semantic Brief** — outline, keywords, gaps, tone anchors.
5. **Draft Generation** — RAG + LLM generates sections to HTML.
6. **Safety & QA** — similarity, plagiarism, SEO checks, factual flags.
7. **Human Review & Export** — editor approves, system exports JSON/HTML payload.

## Architecture & Tooling (summary)
- **Fetch:** node-fetch / axios (fast), Playwright (fallback)
- **Parsing:** Cheerio, Readability helpers
- **NLP & Embeddings:** spaCy / small LLM for NER; OpenAI embeddings or equivalent
- **Vector DB:** Pinecone or Weaviate
- **LLM:** High-quality LLM for final drafts (GPT-5 / Claude); smaller models for extraction/outline
- **Orchestration:** Supabase Functions / Temporal; Postgres + S3 for storage
- **Safety:** Copyleaks / Turnitin (optional), internal embedding similarity checks
- **Monitoring:** Prometheus/Grafana or Datadog, logs, dashboards

## Metrics & Testing
- **Originality Score** (paragraph-level embedding similarity) — target: below threshold (e.g., 0.85)
- **SEO Score** — target ≥ 80%
- **Draft Readiness** — target ≥ 8/10 (editor rating)
- **Latency** — target < 30s (fast-path)
- **Cost per Draft** — track token & API spend

**Tests:** unit tests for extraction, E2E on 100 sample URLs, editorial audits, alerts for threshold breaches.

## Running the scaffold
1. `npm install`
2. `npm run start -- <COMPETITOR_URL>`

The scaffold contains stubbed LLM calls and safe placeholders. Replace with actual LLM clients and vector DB when wiring in production.



## Environment & LLMs

Rename `.env.example` to `.env` and set `OPENAI_API_KEY` to enable real OpenAI generation.

## Heuristic Test

Run `npm run test:heuristics` to evaluate the fetch heuristics on `sample_urls.json`. Output: `heuristic_report.json`.


## CI / GitHub Actions

A GitHub Actions workflow `heuristic-test.yml` runs `npm run test:heuristics` on push/PR. Add `OPENAI_API_KEY` or `CLAUDE_API_KEY` to repository secrets to enable LLM-backed generation in CI.

## LLMs

This scaffold supports either OpenAI (Responses API) or a Claude-compatible API via `CLAUDE_API_KEY`. The code will choose OpenAI if `OPENAI_API_KEY` is present, otherwise Claude if `CLAUDE_API_KEY` is present.
